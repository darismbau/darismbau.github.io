import sys
import socket
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QLineEdit,
    QTextEdit, QPushButton, QLabel, QWidget, QMessageBox, QProgressBar
)
from PyQt6.QtGui import QFont, QIcon
from PyQt6.QtCore import Qt


class ClientDaris(QMainWindow):
    """
    Interface graphique pour le client 2.
    Ce client envoie des programmes au serveur, suit une barre de progression,
    et affiche les résultats reçus.
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Client 2 - Cluster de calcul")
        self.setGeometry(200, 100, 500, 700)
        self.setWindowIcon(QIcon("--.jpg"))

        # arrière-plan
        self.setStyleSheet("""
            QMainWindow {
                background-color: qlineargradient(
                    spread: pad, x1:0, y1:0, x2:1, y2:1,
                    stop: 0 #1F1C2C, stop: 1 #928DAB
                );
            }
        """)

        self.socket_client = None  # Socket pour gérer la connexion au serveur
        self.init_ui()

    def init_ui(self):
        """
        Configure les éléments de l'interface graphique :
        champs d'entrée, boutons, zones de texte et barre de progression.
        """
        # Titre principal
        self.titre_principal = QLabel("Interface Client 2 - Cluster de Calcul")
        self.titre_principal.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.titre_principal.setStyleSheet("color: white; font-size: 28px; font-weight: bold;")
        self.titre_principal.setFont(QFont("Arial", 28))

        # Message d'accueil
        self.message_accueil = QLabel("Entrez le code à exécuter et envoyez-le au serveur.")
        self.message_accueil.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.message_accueil.setStyleSheet("color: #FFD700; font-size: 16px; font-style: italic;")

        # Champs pour adresse et port
        self.label_adresse = QLabel("Adresse IP :", self)
        self.label_adresse.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        self.input_adresse = QLineEdit("127.0.0.1", self)
        self.input_adresse.setStyleSheet("border: 2px solid #4CAF50; border-radius: 5px; padding: 8px; font-size: 14px;")

        self.label_port = QLabel("Port :", self)
        self.label_port.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        self.input_port = QLineEdit("2048", self)
        self.input_port.setStyleSheet("border: 2px solid #4CAF50; border-radius: 5px; padding: 8px; font-size: 14px;")

        # Bouton pour se connecter au serveur
        self.bouton_connecter = QPushButton("Connecter au serveur", self)
        self.bouton_connecter.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border-radius: 10px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1E88E5;
            }
            QPushButton:pressed {
                background-color: #1565C0;
            }
        """)
        self.bouton_connecter.clicked.connect(self.connecter_au_serveur)

        # Bouton pour envoyer le code
        self.bouton_envoyer = QPushButton("Envoyer au serveur", self)
        self.bouton_envoyer.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border-radius: 10px;
                padding: 12px;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #388E3C;
            }
        """)
        self.bouton_envoyer.clicked.connect(self.envoyer_code)

        # Bouton pour se déconnecter du serveur
        self.bouton_deconnecter = QPushButton("Déconnecter du serveur", self)
        self.bouton_deconnecter.setStyleSheet("""
            QPushButton {
                background-color: #FF5722;
                color: white;
                border-radius: 10px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #E64A19;
            }
            QPushButton:pressed {
                background-color: #D84315;
            }
        """)
        self.bouton_deconnecter.clicked.connect(self.deconnecter_serveur)

        # Barre de progression
        self.progress_bar = QProgressBar(self)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 2px solid #2196F3;
                border-radius: 5px;
                text-align: center;
                background-color: #2C3E50;
                color: white;
            }
            QProgressBar::chunk {
                background-color: #3498DB;
                width: 20px;
            }
        """)
        self.progress_bar.setValue(0)

        # Zone de texte pour afficher le résultat
        self.label_resultat = QLabel("Résultat :", self)
        self.label_resultat.setStyleSheet("color: white; font-size: 20px; font-weight: bold;")
        self.zone_resultat = QTextEdit(self)
        self.zone_resultat.setReadOnly(True)
        self.zone_resultat.setStyleSheet("""
            border: 2px solid #2196F3;
            border-radius: 8px;
            padding: 10px;
            background-color: black;
            color: white;
            font-size: 20px;
        """)

        # Zone pour entrer le code
        self.label_code = QLabel("Code à envoyer :", self)
        self.label_code.setStyleSheet("color: white; font-size: 18px; font-weight: bold;")
        self.zone_code = QTextEdit(self)
        self.zone_code.setPlaceholderText("Écrivez ici votre programme Python, java, C ou C++ ...")
        self.zone_code.setStyleSheet("""
            border: 2px solid #FF5722;
            border-radius: 8px;
            padding: 10px;
            background-color: #393E46;
            color: white;
            font-size: 25px;
        """)

        # Layout principal
        layout_principal = QVBoxLayout()

        # Titre et message d'accueil
        layout_principal.addWidget(self.titre_principal)
        layout_principal.addWidget(self.message_accueil)

        # Ligne pour adresse et port
        ligne_adresse_port = QHBoxLayout()
        ligne_adresse_port.addWidget(self.label_adresse)
        ligne_adresse_port.addWidget(self.input_adresse)
        ligne_adresse_port.addWidget(self.label_port)
        ligne_adresse_port.addWidget(self.input_port)

        layout_principal.addLayout(ligne_adresse_port)
        layout_principal.addWidget(self.bouton_connecter)
        layout_principal.addWidget(self.label_code)
        layout_principal.addWidget(self.zone_code)
        layout_principal.addWidget(self.bouton_envoyer)
        layout_principal.addWidget(self.bouton_deconnecter)
        layout_principal.addWidget(self.progress_bar)
        layout_principal.addWidget(self.label_resultat)
        layout_principal.addWidget(self.zone_resultat)

        # Widget central
        widget_central = QWidget()
        widget_central.setLayout(layout_principal)
        self.setCentralWidget(widget_central)

    def connecter_au_serveur(self):
        """
        Connecte le client au serveur en utilisant l'adresse IP et le port donnés.
        """
        adresse = self.input_adresse.text().strip()
        port = self.input_port.text().strip()

        if not adresse or not port:
            QMessageBox.warning(self, "Erreur", "Veuillez remplir l'adresse IP et le port.")
            return

        try:
            port = int(port)
            self.socket_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket_client.connect((adresse, port))
            QMessageBox.information(self, "Connexion réussie", "Connecté au serveur.")
        except Exception as e:
            QMessageBox.critical(self, "Erreur", f"Impossible de se connecter au serveur :\n{e}")
            self.socket_client = None

    def envoyer_code(self):
        """
        Envoie le code saisi au serveur et affiche le résultat avec une barre de progression.
        """
        if not self.socket_client:
            QMessageBox.warning(self, "Erreur", "Vous devez d'abord vous connecter au serveur.")
            return

        code = self.zone_code.toPlainText().strip()
        if not code:
            QMessageBox.warning(self, "Erreur", "Veuillez entrer un code à envoyer.")
            return

        try:
            self.progress_bar.setValue(25)
            self.socket_client.sendall(code.encode('utf-8'))
            self.progress_bar.setValue(50)
            reponse = self.socket_client.recv(4096).decode('utf-8')
            self.zone_resultat.setPlainText(f"{reponse}")
            self.progress_bar.setValue(100)
        except Exception as e:
            self.zone_resultat.setPlainText(f"Erreur : {str(e)}")
            QMessageBox.critical(self, "Erreur", f"Une erreur s'est produite :\n{e}")
            self.progress_bar.setValue(0)

    def deconnecter_serveur(self):
        """
        Déconnecte le client du serveur.
        """
        if self.socket_client:
            try:
                self.socket_client.close()
                self.socket_client = None
                QMessageBox.information(self, "Déconnexion réussie", "Déconnecté du serveur.")
            except Exception as e:
                QMessageBox.warning(self, "Erreur", f"Impossible de se déconnecter : {e}")
        else:
            QMessageBox.warning(self, "Déjà déconnecté", "Vous n'êtes pas connecté au serveur.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    client = ClientDaris()
    client.show()
    sys.exit(app.exec())
