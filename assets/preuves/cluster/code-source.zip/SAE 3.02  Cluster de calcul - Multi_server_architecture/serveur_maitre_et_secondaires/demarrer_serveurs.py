import subprocess
import json

def demarrer_serveurs():
    with open("config.json", "r") as fichier:
        config = json.load(fichier)

    # Démarrer le serveur maître
    subprocess.Popen(["python", "serveur_maitre.py"])
    print("Serveur maître démarré.")

    # Démarrer les serveurs esclaves
    for esclave in config["serveurs_secondaires"]:
        nom_script = f"{esclave['nom']}.py"
        subprocess.Popen(["python", nom_script])
        print(f"{esclave['nom']} démarré.")

if __name__ == "__main__":
    demarrer_serveurs()