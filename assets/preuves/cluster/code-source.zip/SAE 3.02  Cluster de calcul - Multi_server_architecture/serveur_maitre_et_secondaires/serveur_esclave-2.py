import socket
import subprocess
import json
import os
import psutil


class ServeurEsclave2:
    """
    Ceci est le programme pour le serveur esclave numéro 2.
    Il reçoit des programmes du serveur maître, les exécute,
    et renvoie soit les résultats d'exécution, soit son état (CPU, mémoire).
    """

    def __init__(self, fichier_config="config.json", nom="serveur_esclave-2"):
        """
        Prépare le serveur esclave 2 avec ses paramètres depuis un fichier.

        Args:
            fichier_config (str): Fichier contenant la configuration.
            nom (str): Nom de ce serveur esclave (ici "serveur_esclave-2").
        """
        self.config = self.charger_config(fichier_config)
        self.nom = nom
        self.ip, self.port = self.trouver_config_esclave()

    def charger_config(self, fichier_config):
        """
        Charge les paramètres depuis un fichier JSON.

        Args:
            fichier_config (str): Chemin du fichier de configuration.

        Returns:
            dict: Les paramètres du fichier.
        """
        with open(fichier_config, "r") as fichier:
            return json.load(fichier)

    def trouver_config_esclave(self):
        """
        Récupère l'adresse IP et le port associés à ce serveur.

        Returns:
            tuple: Contient l'IP et le port.

        Raises:
            ValueError: Si aucune configuration n'est trouvée pour ce serveur.
        """
        for esclave in self.config["serveurs_secondaires"]:
            if esclave["nom"] == self.nom:
                return esclave["ip"], esclave["port"]
        raise ValueError(f"Aucune configuration pour {self.nom}")

    def demarrer(self):
        """
        Lance le serveur esclave 2. Il écoute les messages du serveur maître.
        Ces messages peuvent demander l'exécution d'un programme
        ou des infos sur le serveur.
        """
        serveur_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        serveur_socket.bind((self.ip, self.port))
        serveur_socket.listen(5)
        print(f"{self.nom} est actif sur {self.ip}:{self.port}")

        while True:
            socket_maitre, adresse = serveur_socket.accept()
            message = socket_maitre.recv(4096).decode('utf-8')

            if message == "MONITORING":
                # Renvoie les infos comme l'utilisation CPU et mémoire
                monitoring_data = self.obtenir_etat()
                socket_maitre.send(json.dumps(monitoring_data).encode('utf-8'))
            else:
                # Reçoit un programme à exécuter
                resultat = self.executer_programme(message)
                socket_maitre.send(resultat.encode('utf-8'))

    def obtenir_etat(self):
        """
        Fournit l'état du serveur : utilisation CPU et mémoire.

        Returns:
            dict: Données sur les ressources utilisées par le serveur.
        """
        return {
            "nom": self.nom,
            "cpu": psutil.cpu_percent(interval=1),
            "memoire": psutil.virtual_memory().percent,
            "programmes_en_cours": 0  # Peut être modifié si suivi ajouté.
        }

    def executer_programme(self, programme):
        """
        Exécute un programme envoyé par le serveur maître.

        Args:
            programme (str): Le code source du programme.

        Returns:
            str: Résultat ou erreur d'exécution.
        """
        try:
            if programme.strip().startswith("class ") or programme.strip().startswith("public "):
                return self.executer_java(programme)
            elif programme.strip().startswith("#include"):
                if "std::" in programme:
                    return self.executer_cpp(programme)
                else:
                    return self.executer_c(programme)
            else:
                return self.executer_python(programme)
        except Exception as e:
            return f"Erreur lors de l'exécution : {str(e)}"

    def executer_python(self, programme):
        """
        Exécute un programme écrit en Python.

        Args:
            programme (str): Code source Python.

        Returns:
            str: Résultat ou erreur.
        """
        try:
            sortie = subprocess.run(['python', '-c', programme], capture_output=True, text=True)
            return sortie.stdout if sortie.stdout else sortie.stderr
        except Exception as e:
            return f"Erreur Python : {str(e)}"

    def executer_java(self, programme):
        """
        Compile et exécute un programme Java.

        Args:
            programme (str): Code source Java.

        Returns:
            str: Résultat ou erreur.
        """
        try:
            class_name = self.extraire_nom_classe_java(programme)
            if not class_name:
                return "Erreur : Classe publique introuvable."

            java_file = f"{class_name}.java"

            with open(java_file, "w") as f:
                f.write(programme)

            compilation = subprocess.run(["javac", java_file], capture_output=True, text=True)
            if compilation.returncode != 0:
                return f"Erreur de compilation Java : {compilation.stderr}"

            execution = subprocess.run(["java", class_name], capture_output=True, text=True)
            return execution.stdout if execution.stdout else execution.stderr
        except Exception as e:
            return f"Erreur Java : {str(e)}"
        finally:
            if os.path.exists(java_file):
                os.remove(java_file)
            class_file = f"{class_name}.class"
            if os.path.exists(class_file):
                os.remove(class_file)

    def executer_c(self, programme):
        """
        Compile et exécute un programme écrit en C.

        Args:
            programme (str): Code source en C.

        Returns:
            str: Résultat ou erreur.
        """
        try:
            c_file = os.path.abspath("programme.c")
            exe_file = os.path.abspath("programme.exe")

            with open(c_file, "w", encoding="utf-8") as f:
                f.write(programme)

            compilation = subprocess.run(["gcc", c_file, "-o", exe_file], capture_output=True, text=True)
            if compilation.returncode != 0:
                return f"Erreur de compilation C : {compilation.stderr}"

            execution = subprocess.run([exe_file], capture_output=True, text=True)
            return execution.stdout if execution.stdout else execution.stderr
        except Exception as e:
            return f"Erreur C : {str(e)}"
        finally:
            if os.path.exists(c_file):
                os.remove(c_file)
            if os.path.exists(exe_file):
                os.remove(exe_file)

    def executer_cpp(self, programme):
        """
        Compile et exécute un programme écrit en C++.

        Args:
            programme (str): Code source en C++.

        Returns:
            str: Résultat ou erreur.
        """
        try:
            cpp_file = os.path.abspath("programme.cpp")
            exe_file = os.path.abspath("programme.exe")

            with open(cpp_file, "w", encoding="utf-8") as f:
                f.write(programme)

            compilation = subprocess.run(["g++", cpp_file, "-o", exe_file], capture_output=True, text=True)
            if compilation.returncode != 0:
                return f"Erreur de compilation C++ : {compilation.stderr}"

            execution = subprocess.run([exe_file], capture_output=True, text=True)
            return execution.stdout if execution.stdout else execution.stderr
        except Exception as e:
            return f"Erreur C++ : {str(e)}"
        finally:
            if os.path.exists(cpp_file):
                os.remove(cpp_file)
            if os.path.exists(exe_file):
                os.remove(exe_file)

    def extraire_nom_classe_java(self, programme):
        """
        Trouve le nom de la classe publique dans un code Java.

        Args:
            programme (str): Le code Java.

        Returns:
            str | None: Nom de la classe ou None si introuvable.
        """
        import re
        match = re.search(r'public\s+class\s+(\w+)', programme)
        if match:
            return match.group(1)
        return None


if __name__ == "__main__":
    # Lance le serveur esclave 2
    esclave = ServeurEsclave2(fichier_config="config.json", nom="serveur_esclave-2")
    esclave.demarrer()