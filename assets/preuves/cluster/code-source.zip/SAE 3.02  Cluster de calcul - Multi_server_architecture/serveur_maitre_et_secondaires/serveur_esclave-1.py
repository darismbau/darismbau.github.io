import socket
import subprocess
import json
import os
import psutil


class ServeurEsclave1:
    """
    Ce programme représente le serveur esclave 1.
    Il reçoit des programmes du serveur maître, les exécute,
    et renvoie les résultats ou des informations sur son état (CPU, mémoire).
    """

    def __init__(self, fichier_config="config.json", nom="serveur_esclave-1"):
        """
        Prépare le serveur esclave 1 en chargeant ses paramètres.

        Args:
            fichier_config (str): Le fichier JSON où sont stockés les paramètres.
            nom (str): Le nom de ce serveur esclave.
        """
        self.config = self.charger_config(fichier_config)
        self.nom = nom
        self.ip, self.port = self.trouver_config_esclave()

    def charger_config(self, fichier_config):
        """
        Lit et charge la configuration depuis un fichier JSON.

        Args:
            fichier_config (str): Le chemin vers le fichier JSON.

        Returns:
            dict: Les données de configuration.
        """
        with open(fichier_config, "r") as fichier:
            return json.load(fichier)

    def trouver_config_esclave(self):
        """
        Trouve l'adresse IP et le port associés à ce serveur esclave.

        Returns:
            tuple: (IP, port).

        Raises:
            ValueError: Si aucune configuration pour ce serveur n'est trouvée.
        """
        for esclave in self.config["serveurs_secondaires"]:
            if esclave["nom"] == self.nom:
                return esclave["ip"], esclave["port"]
        raise ValueError(f"Pas de configuration trouvée pour {self.nom}")

    def demarrer(self):
        """
        Démarre le serveur esclave 1.
        Il attend des messages du serveur maître pour exécuter des programmes ou fournir des infos.
        """
        serveur_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        serveur_socket.bind((self.ip, self.port))
        serveur_socket.listen(5)
        print(f"{self.nom} est prêt à écouter sur {self.ip}:{self.port}")

        while True:
            socket_maitre, adresse = serveur_socket.accept()
            message = socket_maitre.recv(4096).decode('utf-8')

            if message == "MONITORING":
                # Retourne les informations sur l'état du serveur (CPU, mémoire)
                monitoring_data = self.obtenir_etat()
                socket_maitre.send(json.dumps(monitoring_data).encode('utf-8'))
            else:
                # Exécute un programme reçu
                resultat = self.executer_programme(message)
                socket_maitre.send(resultat.encode('utf-8'))

    def obtenir_etat(self):
        """
        Donne l'état actuel du serveur esclave (utilisation du CPU, mémoire).

        Returns:
            dict: Les infos sur le serveur.
        """
        return {
            "nom": self.nom,
            "cpu": psutil.cpu_percent(interval=1),
            "memoire": psutil.virtual_memory().percent,
            "programmes_en_cours": 0  # Peut être changé si un suivi est ajouté.
        }

    def executer_programme(self, programme):
        """
        Exécute un programme reçu selon son langage (Python, Java, C, C++).

        Args:
            programme (str): Le code source du programme.

        Returns:
            str: Le résultat de l'exécution ou une erreur.
        """
        try:
            if programme.strip().startswith("class ") or programme.strip().startswith("public "):
                return self.executer_java(programme)
            elif programme.strip().startswith("#include"):
                if "std::" in programme:
                    return self.executer_cpp(programme)
                else:
                    return self.executer_c(programme)
            else:
                return self.executer_python(programme)
        except Exception as e:
            return f"Erreur d'exécution : {str(e)}"

    def executer_python(self, programme):
        """
        Lance un programme écrit en Python.

        Args:
            programme (str): Le code Python.

        Returns:
            str: Le résultat ou une erreur.
        """
        try:
            sortie = subprocess.run(['python', '-c', programme], capture_output=True, text=True)
            return sortie.stdout if sortie.stdout else sortie.stderr
        except Exception as e:
            return f"Erreur Python : {str(e)}"

    def executer_java(self, programme):
        """
        Compile et exécute un programme Java.

        Args:
            programme (str): Le code Java.

        Returns:
            str: Le résultat ou une erreur.
        """
        try:
            class_name = self.extraire_nom_classe_java(programme)
            if not class_name:
                return "Erreur : Classe publique introuvable."

            java_file = f"{class_name}.java"

            with open(java_file, "w") as f:
                f.write(programme)

            compilation = subprocess.run(["javac", java_file], capture_output=True, text=True)
            if compilation.returncode != 0:
                return f"Erreur de compilation Java : {compilation.stderr}"

            execution = subprocess.run(["java", class_name], capture_output=True, text=True)
            return execution.stdout if execution.stdout else execution.stderr
        except Exception as e:
            return f"Erreur Java : {str(e)}"
        finally:
            if os.path.exists(java_file):
                os.remove(java_file)
            class_file = f"{class_name}.class"
            if os.path.exists(class_file):
                os.remove(class_file)

    def executer_c(self, programme):
        """
        Compile et exécute un programme en langage C.

        Args:
            programme (str): Le code en C.

        Returns:
            str: Le résultat ou une erreur.
        """
        try:
            c_file = os.path.abspath("programme.c")
            exe_file = os.path.abspath("programme.exe")

            with open(c_file, "w", encoding="utf-8") as f:
                f.write(programme)

            compilation = subprocess.run(["gcc", c_file, "-o", exe_file], capture_output=True, text=True)
            if compilation.returncode != 0:
                return f"Erreur de compilation C : {compilation.stderr}"

            execution = subprocess.run([exe_file], capture_output=True, text=True)
            return execution.stdout if execution.stdout else execution.stderr
        except Exception as e:
            return f"Erreur C : {str(e)}"
        finally:
            if os.path.exists(c_file):
                os.remove(c_file)
            if os.path.exists(exe_file):
                os.remove(exe_file)

    def executer_cpp(self, programme):
        """
        Compile et exécute un programme en langage C++.

        Args:
            programme (str): Le code en C++.

        Returns:
            str: Le résultat ou une erreur.
        """
        try:
            cpp_file = os.path.abspath("programme.cpp")
            exe_file = os.path.abspath("programme.exe")

            with open(cpp_file, "w", encoding="utf-8") as f:
                f.write(programme)

            compilation = subprocess.run(["g++", cpp_file, "-o", exe_file], capture_output=True, text=True)
            if compilation.returncode != 0:
                return f"Erreur de compilation C++ : {compilation.stderr}"

            execution = subprocess.run([exe_file], capture_output=True, text=True)
            return execution.stdout if execution.stdout else execution.stderr
        except Exception as e:
            return f"Erreur C++ : {str(e)}"
        finally:
            if os.path.exists(cpp_file):
                os.remove(cpp_file)
            if os.path.exists(exe_file):
                os.remove(exe_file)

    def extraire_nom_classe_java(self, programme):
        """
        Trouve le nom de la classe publique dans un code Java.

        Args:
            programme (str): Le code Java.

        Returns:
            str | None: Le nom de la classe ou None si introuvable.
        """
        import re
        match = re.search(r'public\s+class\s+(\w+)', programme)
        if match:
            return match.group(1)
        return None


if __name__ == "__main__":
    # Lance le serveur esclave 1
    esclave = ServeurEsclave1(fichier_config="config.json", nom="serveur_esclave-1")
    esclave.demarrer()