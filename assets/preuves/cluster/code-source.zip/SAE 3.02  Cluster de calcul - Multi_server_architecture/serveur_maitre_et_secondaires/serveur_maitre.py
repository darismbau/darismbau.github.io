import socket
import threading
import json
import psutil
from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QTableWidget, QTableWidgetItem, QLabel, QWidget
from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QFont, QIcon
import sys

class ServeurMaitre:
    """
    Ce serveur maître gère les clients et délègue les tâches aux serveurs esclaves.
    Il surveille aussi les ressources du système pour équilibrer la charge.
    """

    def __init__(self, fichier_config="config.json"):
        """
        Initialise le serveur maître avec la configuration du fichier JSON.

        Args:
            fichier_config (str): Le nom du fichier de configuration.
        """
        self.config = self.charger_config(fichier_config)
        self.hote = self.config["serveur_maitre"]["ip"]
        self.port = self.config["serveur_maitre"]["port"]
        self.seuil_cpu = self.config["serveur_maitre"]["seuil_cpu"]
        self.seuil_memoire = self.config["serveur_maitre"]["seuil_memoire"]
        self.esclaves = [(srv["nom"], srv["ip"], srv["port"]) for srv in self.config["serveurs_secondaires"]]

        self.socket_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket_serveur.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket_serveur.bind((self.hote, self.port))
        self.socket_serveur.listen(5)
        print(f"Serveur maître démarré sur {self.hote}:{self.port}")

    def charger_config(self, fichier_config):
        """
        Charge la configuration du serveur depuis un fichier JSON.

        Args:
            fichier_config (str): Le chemin du fichier de configuration.

        Returns:
            dict: La configuration sous forme de dictionnaire.
        """
        with open(fichier_config, "r") as fichier:
            return json.load(fichier)

    def demarrer(self):
        """
        Lance le serveur maître pour accepter les connexions des clients.
        """
        print("Serveur maître en attente de connexions...")
        while True:
            socket_client, adresse = self.socket_serveur.accept()
            print(f"Connexion établie avec {adresse}")
            thread_client = threading.Thread(target=self.traiter_client, args=(socket_client,))
            thread_client.start()

    def traiter_client(self, socket_client):
        """
        Gère les interactions avec un client connecté.

        Args:
            socket_client (socket): La connexion socket du client.
        """
        try:
            while True:
                programme = socket_client.recv(4096).decode('utf-8')
                if not programme:  # Si le client ferme la connexion
                    print("Connexion fermée par le client.")
                    break

                if programme.strip().upper() == "EXIT":  # Commande pour quitter
                    print("Commande de déconnexion reçue.")
                    break

                resultat = self.repartir_charge(programme)
                socket_client.send(resultat.encode('utf-8'))
        except Exception as e:
            print(f"Erreur lors du traitement du client : {e}")
            socket_client.send(f"Erreur : {str(e)}".encode('utf-8'))
        finally:
            socket_client.close()
            print("Connexion terminée avec le client.")

    def surveiller_ressources(self):
        """
        Vérifie l'utilisation du CPU et de la mémoire du serveur.

        Returns:
            tuple: Pourcentage d'utilisation du CPU et de la mémoire.
        """
        utilisation_cpu = psutil.cpu_percent(interval=1)
        utilisation_memoire = psutil.virtual_memory().percent
        return utilisation_cpu, utilisation_memoire

    def repartir_charge(self, programme):
        """
        Envoie le programme à un esclave pour traitement.

        Args:
            programme (str): Le programme à exécuter.

        Returns:
            str: Le résultat de l'exécution.
        """
        for nom, ip, port in self.esclaves:
            try:
                return self.envoyer_a_esclave(ip, port, programme)
            except Exception as e:
                print(f"Erreur avec l'esclave {nom} ({ip}:{port}): {e}")
        return "Tous les esclaves sont inaccessibles."

    def envoyer_a_esclave(self, ip, port, programme):
        """
        Transfère un programme à un serveur esclave pour exécution.

        Args:
            ip (str): L'adresse IP de l'esclave.
            port (int): Le port de l'esclave.
            programme (str): Le programme à envoyer.

        Returns:
            str: Le résultat de l'exécution par l'esclave.
        """
        try:
            socket_esclave = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            socket_esclave.connect((ip, port))
            socket_esclave.send(programme.encode('utf-8'))
            resultat = socket_esclave.recv(4096).decode('utf-8')
            socket_esclave.close()
            return resultat
        except Exception as e:
            raise Exception(f"Impossible de contacter l'esclave ({ip}:{port}): {e}")

class InterfaceMonitoring(QMainWindow):
    """
    Interface graphique pour surveiller l'état du cluster de serveurs.
    Affiche les charges CPU et mémoire des serveurs esclaves.
    """

    def __init__(self, esclaves):
        """
        Initialise l'interface graphique avec les informations des esclaves.

        Args:
            esclaves (list): Liste des esclaves sous forme de tuples (nom, ip, port).
        """
        super().__init__()
        self.setWindowTitle("Monitoring du Cluster")
        self.setFixedSize(400, 150)
        self.setWindowIcon(QIcon("../--.jpg"))
        self.esclaves = esclaves

        self.init_ui()

        # Met à jour les données toutes les 3 secondes
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.mettre_a_jour_tableau)
        self.timer.start(3000)

    def init_ui(self):
        """
        Configure l'interface utilisateur avec un titre et un tableau pour les données des esclaves.
        """
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)  # Supprime les marges

        # Titre de l'interface
        self.label_titre = QLabel("État du Cluster", self)
        self.label_titre.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_titre.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        self.label_titre.setStyleSheet("""
            color: #FFFFFF;
            background-color: #1E1E1E; /* Noir */
            padding: 10px;
        """)
        layout.addWidget(self.label_titre)

        # Tableau pour afficher les données des esclaves
        self.tableau = QTableWidget(self)
        self.tableau.setRowCount(len(self.esclaves))
        self.tableau.setColumnCount(3)
        self.tableau.setHorizontalHeaderLabels(["Nom", "Charge CPU (%)", "Mémoire (%)"])
        self.tableau.setStyleSheet("""
            QTableWidget {
                border: 1px solid #FFFFFF; /* Blanc */
                background-color: #000000; /* Noir */
                color: #FFFFFF; /* Blanc */
                gridline-color: #707070; /* Gris */
            }
            QHeaderView::section {
                background-color: #444444; /* Gris foncé */
                color: #FFFFFF; /* Blanc */
                font-weight: bold;
                text-align: center;
            }
            QTableWidget::item {
                padding: 5px;
            }
        """)
        self.tableau.setFont(QFont("Arial", 10))
        self.tableau.verticalHeader().setVisible(False)  # Cache les en-têtes des lignes
        self.tableau.horizontalHeader().setStretchLastSection(True)  # Ajuste la dernière colonne
        self.tableau.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.tableau)

        # Ajoute le layout au widget central
        widget_central = QWidget()
        widget_central.setLayout(layout)
        self.setCentralWidget(widget_central)

    def mettre_a_jour_tableau(self):
        """
        Met à jour le tableau avec les données actuelles des esclaves.
        Les informations incluent la charge CPU et l'utilisation mémoire.
        """
        for i, (nom, ip, port) in enumerate(self.esclaves):
            etat = self.demander_etat_esclave(ip, port)

            if etat:
                self.tableau.setItem(i, 0, QTableWidgetItem(nom))
                cpu_item = QTableWidgetItem(f"{etat['cpu']}%")
                mem_item = QTableWidgetItem(f"{etat['memoire']}%")

                # Couleur selon la charge CPU
                if etat["cpu"] < 50:
                    cpu_item.setForeground(Qt.GlobalColor.green)
                elif etat["cpu"] < 80:
                    cpu_item.setForeground(Qt.GlobalColor.yellow)
                else:
                    cpu_item.setForeground(Qt.GlobalColor.red)

                # Couleur selon la mémoire utilisée
                if etat["memoire"] < 50:
                    mem_item.setForeground(Qt.GlobalColor.green)
                elif etat["memoire"] < 80:
                    mem_item.setForeground(Qt.GlobalColor.yellow)
                else:
                    mem_item.setForeground(Qt.GlobalColor.red)

                self.tableau.setItem(i, 1, cpu_item)
                self.tableau.setItem(i, 2, mem_item)
            else:
                self.tableau.setItem(i, 0, QTableWidgetItem(nom))
                self.tableau.setItem(i, 1, QTableWidgetItem("Inaccessible"))
                self.tableau.setItem(i, 2, QTableWidgetItem("Inaccessible"))

    def demander_etat_esclave(self, ip, port):
        """
        Envoie une requête à un esclave pour obtenir son état.

        Args:
            ip (str): Adresse IP de l'esclave.
            port (int): Port de l'esclave.

        Returns:
            dict | None: Un dictionnaire contenant la charge CPU et mémoire,
                         ou None si l'esclave est inaccessible.
        """
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((ip, port))
                s.send("MONITORING".encode('utf-8'))
                reponse = s.recv(4096).decode('utf-8')
                return json.loads(reponse)
        except Exception as e:
            print(f"Erreur de connexion avec l'esclave {ip}:{port} : {e}")
            return None

if __name__ == "__main__":
    # Charge la configuration des esclaves
    with open("config.json", "r") as fichier:
        config = json.load(fichier)

    esclaves = [(srv["nom"], srv["ip"], srv["port"]) for srv in config["serveurs_secondaires"]]

    # Lance l'application de monitoring dans un thread séparé
    app = QApplication(sys.argv)
    monitoring = InterfaceMonitoring(esclaves)
    monitoring.show()

    # Démarre le serveur maître
    serveur = ServeurMaitre(fichier_config="config.json")
    thread_maitre = threading.Thread(target=serveur.demarrer)
    thread_maitre.start()

    sys.exit(app.exec())