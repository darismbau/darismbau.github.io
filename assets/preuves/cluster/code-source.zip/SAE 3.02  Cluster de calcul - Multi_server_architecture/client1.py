import sys
import socket
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QLineEdit,
    QTextEdit, QPushButton, QLabel, QWidget, QMessageBox
)
from PyQt6.QtGui import QFont, QIcon
from PyQt6.QtCore import Qt


class ClientDaris(QMainWindow):
    """
    Interface graphique pour le client 1.
    Ce client permet d'envoyer un programme au serveur,
    de recevoir le résultat, et de se connecter/déconnecter.
    """

    def __init__(self):
        """
        Initialise l'interface utilisateur du client 1.
        """
        super().__init__()
        self.setWindowTitle("Client 1 - Cluster de calcul")
        self.setGeometry(200, 100, 500, 700)
        self.setWindowIcon(QIcon("--.jpg"))

        self.socket_client = None  # Socket pour la connexion au serveur
        self.set_background_image("--.jpg")
        self.init_ui()

    def set_background_image(self, image_path):
        """
        Arrière-plan.
        """
        self.setStyleSheet("""
            QMainWindow {
                background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1,
                                            stop:0 #0055A4, stop:0.5 #FFFFFF, stop:1 #EF4135);
            }
        """)

    def init_ui(self):
        """
        Configuration de tous les éléments, les champs, les boutons, et les zones de texte.
        """
        # Titre principal
        self.titre_principal = QLabel("Bienvenue sur l'interface du client 1")
        self.titre_principal.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.titre_principal.setStyleSheet("color: black; font-size: 24px; font-weight: bold;")
        self.titre_principal.setFont(QFont("Arial", 24))

        # Message d'instructions
        self.message_accueil = QLabel("Entrez votre code et envoyez-le au serveur.")
        self.message_accueil.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.message_accueil.setStyleSheet("color: black; font-size: 14px; font-style: italic;")

        # Champs pour l'adresse IP et le port
        self.label_adresse = QLabel("Adresse IP :", self)
        self.label_adresse.setStyleSheet("color: black; font-size: 14px; font-weight: bold;")
        self.input_adresse = QLineEdit("127.0.0.1", self)
        self.input_adresse.setStyleSheet("border: 2px solid #4CAF50; border-radius: 5px; padding: 5px;")

        self.label_port = QLabel("Port :", self)
        self.label_port.setStyleSheet("color: black; font-size: 14px; font-weight: bold;")
        self.input_port = QLineEdit("2048", self)
        self.input_port.setStyleSheet("border: 2px solid #4CAF50; border-radius: 5px; padding: 5px;")

        # Zone de texte pour le code
        self.label_code = QLabel("Code à envoyer :", self)
        self.label_code.setStyleSheet("color: black; font-size: 16px; font-weight: bold;")
        self.zone_code = QTextEdit(self)
        self.zone_code.setPlaceholderText("Écrivez ici votre programme Python, Java, C ou C++ ...")
        self.zone_code.setStyleSheet(
            "border: 2px solid #FF5722; border-radius: 8px; padding: 8px; background-color: #393E46; color: white; font-size: 20px;"
        )

        # Bouton pour se connecter
        self.bouton_connecter = QPushButton("Connecter au serveur", self)
        self.bouton_connecter.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: black;
                border-radius: 10px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1E88E5;
            }
            QPushButton:pressed {
                background-color: #1565C0;
            }
        """)
        self.bouton_connecter.clicked.connect(self.connecter_au_serveur)

        # Bouton pour envoyer le code
        self.bouton_envoyer = QPushButton("Envoyer au serveur", self)
        self.bouton_envoyer.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: black;
                border-radius: 10px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #388E3C;
            }
        """)
        self.bouton_envoyer.clicked.connect(self.envoyer_code)

        # Bouton pour se déconnecter
        self.bouton_deconnecter = QPushButton("Déconnecter du serveur", self)
        self.bouton_deconnecter.setStyleSheet("""
            QPushButton {
                background-color: #FF5722;
                color: black;
                border-radius: 10px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #E64A19;
            }
            QPushButton:pressed {
                background-color: #D84315;
            }
        """)
        self.bouton_deconnecter.clicked.connect(self.deconnecter_serveur)

        # Zone de résultat
        self.label_resultat = QLabel("Résultat du serveur :", self)
        self.label_resultat.setStyleSheet("color: black; font-size: 16px; font-weight: bold;")
        self.zone_resultat = QTextEdit(self)
        self.zone_resultat.setReadOnly(True)
        self.zone_resultat.setStyleSheet(
            "border: 2px solid #2196F3; border-radius: 8px; padding: 8px; background-color: black; color: white; font-size: 20px;"
        )

        # Layout principal
        layout_principal = QVBoxLayout()
        layout_principal.addWidget(self.titre_principal)
        layout_principal.addWidget(self.message_accueil)

        ligne_adresse_port = QHBoxLayout()
        ligne_adresse_port.addWidget(self.label_adresse)
        ligne_adresse_port.addWidget(self.input_adresse)
        ligne_adresse_port.addWidget(self.label_port)
        ligne_adresse_port.addWidget(self.input_port)

        layout_principal.addLayout(ligne_adresse_port)
        layout_principal.addWidget(self.bouton_connecter)
        layout_principal.addWidget(self.label_code)
        layout_principal.addWidget(self.zone_code)
        layout_principal.addWidget(self.bouton_envoyer)
        layout_principal.addWidget(self.bouton_deconnecter)
        layout_principal.addWidget(self.label_resultat)
        layout_principal.addWidget(self.zone_resultat)

        widget_central = QWidget()
        widget_central.setLayout(layout_principal)
        self.setCentralWidget(widget_central)

    def connecter_au_serveur(self):
        """
        Connecte le client au serveur en utilisant l'adresse IP et le port fournis.
        """
        adresse = self.input_adresse.text().strip()
        port = self.input_port.text().strip()

        if not adresse or not port:
            QMessageBox.warning(self, "Erreur", "Veuillez remplir l'adresse IP et le port.")
            return

        try:
            port = int(port)
            self.socket_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket_client.connect((adresse, port))
            QMessageBox.information(self, "Succès", "Connecté au serveur.")
        except Exception as e:
            QMessageBox.critical(self, "Erreur", f"Connexion impossible : {e}")
            self.socket_client = None

    def envoyer_code(self):
        """
        Envoie le programme saisi dans la zone de texte au serveur.
        """
        if not self.socket_client:
            QMessageBox.warning(self, "Erreur", "Vous devez d'abord vous connecter au serveur.")
            return

        code = self.zone_code.toPlainText().strip()
        if not code:
            QMessageBox.warning(self, "Erreur", "Veuillez entrer un code à envoyer.")
            return

        try:
            self.socket_client.sendall(code.encode('utf-8'))
            reponse = self.socket_client.recv(4096).decode('utf-8')
            self.zone_resultat.setPlainText(reponse)
        except Exception as e:
            QMessageBox.critical(self, "Erreur", f"Erreur lors de l'envoi : {e}")

    def deconnecter_serveur(self):
        """
        Ferme la connexion avec le serveur.
        """
        if self.socket_client:
            try:
                self.socket_client.close()
                self.socket_client = None
                QMessageBox.information(self, "Déconnexion", "Déconnecté du serveur.")
            except Exception as e:
                QMessageBox.warning(self, "Erreur", f"Erreur lors de la déconnexion : {e}")
        else:
            QMessageBox.warning(self, "Déjà déconnecté", "Vous n'êtes pas connecté à un serveur.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    client = ClientDaris()
    client.show()
    sys.exit(app.exec())
